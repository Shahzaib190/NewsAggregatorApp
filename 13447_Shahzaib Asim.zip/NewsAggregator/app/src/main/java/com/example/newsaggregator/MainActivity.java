package com.example.newsaggregator;

import androidx.appcompat.app.AppCompatActivity;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    String myResponse;
    ListView lv;
    Button btn;
    ArrayList<HashMap<String,String>> arrayList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        arrayList=new ArrayList<>();
        lv = (ListView)findViewById(R.id.listview);
        OkHttpClient client = new OkHttpClient();
        String News_url = "https://alasartothepoint.alasartechnologies.com/listItem.php?id=1";
        Request request = new Request.Builder()
                .url(News_url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if(response.isSuccessful())
                {
                    myResponse = response.body().string();
                    MainActivity.this.runOnUiThread(new Runnable() {

                        @Override
                        public void run() {

                            try {
                                JSONObject reader = new JSONObject(myResponse);
                                JSONArray data = reader.getJSONArray("data"); // get the whole json array list
                                System.out.println("json size is : "+data.length());

                                for(int i = 0;i<data.length();i++)
                                {
                                    JSONObject Data = data.getJSONObject(i);

                                    String N_id = Data.getString("id");
                                    String N_Url = Data.getString("url");
                                    String N_description = Data.getString("description");
                                    String N_heading = Data.getString("heading");
                                    System.out.println(i+" ID: "+N_id +" Url : "+N_Url+" Description: "+N_description+" Heading : "+N_heading);
                                    HashMap<String,String> d = new HashMap<>();

                                    d.put("id",N_id);
                                    d.put("heading",N_heading);
                                    d.put("url", N_Url);
                                    d.put("description",N_description);



                                    arrayList.add(d);



                                    ListAdapter adapter = new SimpleAdapter(MainActivity.this,arrayList,R.layout.adapter_list
                                            ,new String[]{"id","url","description","heading"},new int[]{R.id.id,R.id.Url,R.id.description,R.id.heading});
                                    lv.setAdapter(adapter);




                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }

                    });
                }
            }
        });






    }




}
